import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    HeaderComponent,  // Declare HeaderComponent
  ],
  exports: [
    HeaderComponent  // Export HeaderComponent so other modules can use it
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
