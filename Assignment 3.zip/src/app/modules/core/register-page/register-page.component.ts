import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.css']
})
export class RegisterPageComponent implements OnInit {
  provinces: string[] = [];

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadProvinces();
  }

  loadProvinces() {
    this.http.get<{ provinces: string[] }>('provinces.json').subscribe(data => {
      this.provinces = data.provinces;
    });
  }

  onSubmit() {
    // Handle form submission logic here
    alert('Registration Successful! Redirecting to Products Page...');
    this.router.navigate(['/products']);
  }
}
