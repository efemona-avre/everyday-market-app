import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RegisterPageComponent } from './register-page/register-page.component';

@NgModule({
  declarations: [
    RegisterPageComponent,
  
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    RegisterPageComponent,
  ]
})
export class CoreModule { }
